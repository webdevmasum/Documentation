<?php
/**
 * The MERGE storage engine
 */

declare(strict_types=1);

namespace PhpMyAdmin\Engines;

use PhpMyAdmin\StorageEngine;

/**
 * The MERGE storage engine
 */
class Merge extends StorageEngine
{
}
